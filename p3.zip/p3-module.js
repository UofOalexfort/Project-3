

//validDenomination(coin):
//Returns true if the coin function parameter is a valid coin value of either
//1, 5, 10, 25, 50, or 100
//Must use the array indexOf() method, and !== equality operator
//This function can be coded to be a single line of code

//works - is not one line, and might cause problems with the following functions
/* function validDenomination (coin){          
    const coins = [1,5,10,25,50,100]; 
    return coins.indexOf(coin) !== coins.indexOf(1,5,10,25,50,100);
}; */

//refactoring the above,
function validDenomination(coin) {
  return [1, 5, 10, 25, 50, 100].indexOf(coin) !== -1;
}


//valueFromCoinObject(obj):
//Returns the calculated value of a single coin object from the obj function parameter
//Must use object deconstruction to create constant variables denom and count from the
//obj function parameter, using default object values of 0 for denom and count

//deconstruct the function paramater, to equal a value of 1,5,10,25,50,100 for denom, and count can be whatever value, as long as the function retruns result of  denom * count
//console.log will use the destructured obj. This is where the new values will be assigned, overwritng the default

function valueFromCoinObject(obj) {
  const { denom = 0, count = 0 } = obj;
  return validDenomination(denom) ? count * denom : 0;
}

//valueFromArray(arr):

//Iterates through an array of coin objects and returns the final calculated
//value of all coin objects
//Must use Array.reduce() method, and an arrow function with the Array.reduce() method
//Must call valueFromCoinObject()
//Extra credit: Handle scenario where the arr function parameter,
//rather than an array of coin objects, contains another array of coin objects


//console.log outputs that arr.reduce is not a function 
function valueFromArray(arr) {
  return arr.reduce(
    (accumulator, coinObj) => accumulator + valueFromCoinObject(coinObj),0
  );
}

//coinCount(...coinage):

//This function is the only exported function from the code module
//Calls and returns the result of valueFromArray() function, which will
//be the value of all coin objects with the coinage array function parameter

function coinCount(...coinage) {
  return valueFromArray(coinage);
}

module.exports = {coinCount};

//function name (...param) will create an array

//console.logs - ordered from first function to last -comment out when they all seem to work properly
/* console.log(validDenomination(25));
console.log(valueFromCoinObject({ denom: 10, count: 3 }));
console.log(valueFromArray({ denom: 10, count: 3 },{denom: 50, count: 6 }))
console.log(coinCount()) */

console.log("{}", coinCount({denom: 5, count: 3}));
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
console.log("...[{}]", coinCount(...coins));

